const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { BOARD, CHANCE_CARDS, CHEST_CARDS } = require('./board');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, 'public')));

const PLAYER_COLORS = ['#E5514B', '#5FB8D9', '#F0CB4E', '#33B36B', '#C15FE0', '#F2994A'];
const START_MONEY = 1500;
const rooms = {}; // code -> room state

function genCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  let code;
  do {
    code = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  } while (rooms[code]);
  return code;
}

function publicState(room) {
  return {
    code: room.code,
    started: room.started,
    finished: room.finished,
    winner: room.winner,
    turnIndex: room.turnIndex,
    currentDoubles: room.currentDoubles,
    ownership: room.ownership,
    players: room.players.map(p => ({
      id: p.id, name: p.name, color: p.color, money: p.money,
      pos: p.pos, inJail: p.inJail, jailTurns: p.jailTurns,
      bankrupt: p.bankrupt, properties: p.properties,
    })),
    log: room.log.slice(-40),
    pendingAction: room.pendingAction,
    lastRoll: room.lastRoll,
  };
}

function pushLog(room, msg) {
  room.log.push(msg);
  if (room.log.length > 200) room.log.shift();
}

function emitRoom(room) {
  io.to(room.code).emit('room_update', publicState(room));
}

function currentPlayer(room) {
  return room.players[room.turnIndex];
}

function ownedGroupComplete(room, player, group) {
  const tilesInGroup = BOARD.filter(t => t.type === 'street' && t.group === group);
  return tilesInGroup.every(t => room.ownership[t.id] && room.ownership[t.id].owner === player.id);
}

function countOwnedOfType(room, ownerId, type) {
  return BOARD.filter(t => t.type === type && room.ownership[t.id] && room.ownership[t.id].owner === ownerId).length;
}

function calcRent(room, tile, roll) {
  const own = room.ownership[tile.id];
  if (!own) return 0;
  const owner = room.players.find(p => p.id === own.owner);
  if (tile.type === 'street') {
    const houses = own.houses || 0;
    let rent = tile.rentTable[houses];
    if (houses === 0 && ownedGroupComplete(room, owner, tile.group)) rent *= 2;
    return rent;
  }
  if (tile.type === 'railroad') {
    const n = countOwnedOfType(room, owner.id, 'railroad');
    return [0, 25, 50, 100, 200][n] || 0;
  }
  if (tile.type === 'utility') {
    const n = countOwnedOfType(room, owner.id, 'utility');
    return (n >= 2 ? 10 : 4) * roll;
  }
  return 0;
}

function payPlayer(room, fromPlayer, toPlayerOrNull, amount, reason) {
  fromPlayer.money -= amount;
  if (toPlayerOrNull) toPlayerOrNull.money += amount;
  if (fromPlayer.money < 0) {
    handleBankruptcy(room, fromPlayer, toPlayerOrNull, reason);
  }
}

function handleBankruptcy(room, player, creditorOrNull, reason) {
  if (player.bankrupt) return;
  player.bankrupt = true;
  pushLog(room, `💥 ${player.name} обанкротился (${reason}) и выбывает из игры.`);
  // передать имущество
  for (const tid of Object.keys(room.ownership)) {
    const own = room.ownership[tid];
    if (own.owner === player.id) {
      if (creditorOrNull) {
        own.owner = creditorOrNull.id;
        own.houses = 0;
        creditorOrNull.properties.push(Number(tid));
      } else {
        delete room.ownership[tid];
      }
    }
  }
  player.properties = [];
  const alive = room.players.filter(p => !p.bankrupt);
  if (alive.length === 1) {
    room.finished = true;
    room.winner = alive[0].name;
    pushLog(room, `🏆 ${alive[0].name} побеждает в игре!`);
  }
}

function movePlayer(room, player, steps, opts = {}) {
  const oldPos = player.pos;
  let newPos = (oldPos + steps) % 40;
  if (newPos < 0) newPos += 40;
  const passedGo = !opts.noGoCheck && (steps > 0) && (newPos < oldPos || (oldPos + steps) >= 40);
  player.pos = newPos;
  if (passedGo && newPos !== 0) {
    player.money += 200;
    pushLog(room, `💰 ${player.name} проходит Старт и получает $200`);
  }
  return newPos;
}

function sendToJail(room, player) {
  player.pos = 10;
  player.inJail = true;
  player.jailTurns = 0;
  pushLog(room, `🚔 ${player.name} отправляется в тюрьму`);
}

function applyCard(room, player, card) {
  pushLog(room, `🃏 ${player.name}: ${card.text}`);
  switch (card.type) {
    case 'money':
      if (card.amount >= 0) player.money += card.amount;
      else payPlayer(room, player, null, -card.amount, 'карта');
      break;
    case 'move_to': {
      const old = player.pos;
      player.pos = card.pos;
      if (card.collectGo && card.pos <= old) player.money += 200;
      resolveTile(room, player);
      break;
    }
    case 'move_relative':
      movePlayer(room, player, card.steps);
      resolveTile(room, player);
      break;
    case 'goto_jail':
      sendToJail(room, player);
      break;
    case 'repair': {
      let total = 0;
      for (const tid of player.properties) {
        const own = room.ownership[tid];
        if (own && own.houses > 0) total += own.houses === 5 ? card.perHotel : own.houses * card.perHouse;
      }
      if (total > 0) payPlayer(room, player, null, total, 'ремонт');
      break;
    }
    case 'collect_from_all':
      for (const p of room.players) {
        if (p.id !== player.id && !p.bankrupt) payPlayer(room, p, player, card.amount, 'сбор со всех');
      }
      break;
  }
}

function resolveTile(room, player) {
  const tile = BOARD[player.pos];
  room.pendingAction = null;
  switch (tile.type) {
    case 'go':
      break;
    case 'tax':
      payPlayer(room, player, null, tile.amount, tile.name);
      pushLog(room, `🧾 ${player.name} платит ${tile.name}: $${tile.amount}`);
      break;
    case 'luxury_tax':
      payPlayer(room, player, null, tile.amount, tile.name);
      pushLog(room, `🧾 ${player.name} платит ${tile.name}: $${tile.amount}`);
      break;
    case 'chance': {
      const card = CHANCE_CARDS[Math.floor(Math.random() * CHANCE_CARDS.length)];
      applyCard(room, player, card);
      break;
    }
    case 'chest': {
      const card = CHEST_CARDS[Math.floor(Math.random() * CHEST_CARDS.length)];
      applyCard(room, player, card);
      break;
    }
    case 'go_to_jail':
      sendToJail(room, player);
      break;
    case 'free_parking':
    case 'jail':
      break;
    case 'street':
    case 'railroad':
    case 'utility': {
      const own = room.ownership[tile.id];
      if (!own) {
        if (player.money >= tile.price) {
          room.pendingAction = { type: 'buy', tileId: tile.id, playerId: player.id };
        }
        pushLog(room, `📍 ${player.name} на клетке «${tile.name}» (свободна, $${tile.price})`);
      } else if (own.owner !== player.id) {
        const owner = room.players.find(p => p.id === own.owner);
        const rent = calcRent(room, tile, (room.lastRoll ? room.lastRoll.d1 + room.lastRoll.d2 : 0));
        payPlayer(room, player, owner, rent, `аренда «${tile.name}»`);
        pushLog(room, `💸 ${player.name} платит аренду $${rent} игроку ${owner.name} за «${tile.name}»`);
      }
      break;
    }
  }
}

function endTurnInternal(room) {
  room.pendingAction = null;
  room.currentDoubles = 0;
  let next = room.turnIndex;
  do {
    next = (next + 1) % room.players.length;
  } while (room.players[next].bankrupt && next !== room.turnIndex);
  room.turnIndex = next;
}

io.on('connection', (socket) => {
  socket.on('create_room', ({ name }) => {
    const code = genCode();
    const player = {
      id: socket.id, name: name?.slice(0, 16) || 'Игрок', color: PLAYER_COLORS[0],
      money: START_MONEY, pos: 0, inJail: false, jailTurns: 0, bankrupt: false, properties: [],
    };
    rooms[code] = {
      code, players: [player], started: false, finished: false, winner: null,
      turnIndex: 0, currentDoubles: 0, ownership: {}, log: [], pendingAction: null,
      lastRoll: null, hostId: socket.id,
    };
    socket.join(code);
    pushLog(rooms[code], `🎲 Комната ${code} создана игроком ${player.name}`);
    socket.emit('joined', { code, board: BOARD, playerId: socket.id });
    emitRoom(rooms[code]);
  });

  socket.on('join_room', ({ code, name }) => {
    code = (code || '').toUpperCase();
    const room = rooms[code];
    if (!room) return socket.emit('error_msg', 'Комната не найдена');
    if (room.started) return socket.emit('error_msg', 'Игра уже началась');
    if (room.players.length >= 6) return socket.emit('error_msg', 'Комната заполнена');
    const player = {
      id: socket.id, name: name?.slice(0, 16) || 'Игрок', color: PLAYER_COLORS[room.players.length % PLAYER_COLORS.length],
      money: START_MONEY, pos: 0, inJail: false, jailTurns: 0, bankrupt: false, properties: [],
    };
    room.players.push(player);
    socket.join(code);
    pushLog(room, `👋 ${player.name} присоединился к игре`);
    socket.emit('joined', { code, board: BOARD, playerId: socket.id });
    emitRoom(room);
  });

  socket.on('start_game', ({ code }) => {
    const room = rooms[code];
    if (!room || room.hostId !== socket.id) return;
    if (room.players.length < 2) return socket.emit('error_msg', 'Нужно минимум 2 игрока');
    room.started = true;
    pushLog(room, '🚀 Игра началась!');
    emitRoom(room);
  });

  socket.on('roll_dice', ({ code }) => {
    const room = rooms[code];
    if (!room || !room.started || room.finished) return;
    const player = currentPlayer(room);
    if (!player || player.id !== socket.id) return;
    if (room.pendingAction) return;
    const d1 = 1 + Math.floor(Math.random() * 6);
    const d2 = 1 + Math.floor(Math.random() * 6);
    room.lastRoll = { d1, d2 };
    const isDouble = d1 === d2;

    if (player.inJail) {
      if (isDouble) {
        player.inJail = false;
        player.jailTurns = 0;
        pushLog(room, `🔓 ${player.name} выбрасывает дубль и выходит из тюрьмы!`);
        movePlayer(room, player, d1 + d2);
        resolveTile(room, player);
      } else {
        player.jailTurns++;
        pushLog(room, `⛓️ ${player.name} сидит в тюрьме (попытка ${player.jailTurns}/3)`);
        if (player.jailTurns >= 3) {
          payPlayer(room, player, null, 50, 'штраф тюрьмы');
          player.inJail = false;
          player.jailTurns = 0;
          if (!player.bankrupt) {
            movePlayer(room, player, d1 + d2);
            resolveTile(room, player);
          }
        }
      }
      if (!room.pendingAction) endTurnInternal(room);
      emitRoom(room);
      return;
    }

    if (isDouble) {
      room.currentDoubles++;
      if (room.currentDoubles >= 3) {
        pushLog(room, `🚨 ${player.name} выбросил 3 дубля подряд — прямиком в тюрьму!`);
        sendToJail(room, player);
        endTurnInternal(room);
        emitRoom(room);
        return;
      }
    }

    movePlayer(room, player, d1 + d2);
    pushLog(room, `🎲 ${player.name} бросает ${d1} и ${d2}`);
    resolveTile(room, player);

    if (!room.pendingAction && !isDouble) {
      endTurnInternal(room);
    } else if (!room.pendingAction && isDouble) {
      pushLog(room, `✨ Дубль! ${player.name} ходит ещё раз`);
    }
    emitRoom(room);
  });

  socket.on('buy_property', ({ code, accept }) => {
    const room = rooms[code];
    if (!room || !room.pendingAction || room.pendingAction.type !== 'buy') return;
    if (room.pendingAction.playerId !== socket.id) return;
    const player = currentPlayer(room);
    const tile = BOARD[room.pendingAction.tileId];
    if (accept && player.money >= tile.price) {
      player.money -= tile.price;
      room.ownership[tile.id] = { owner: player.id, houses: 0 };
      player.properties.push(tile.id);
      pushLog(room, `🏠 ${player.name} покупает «${tile.name}» за $${tile.price}`);
    } else {
      pushLog(room, `🙅 ${player.name} отказывается от покупки «${tile.name}»`);
    }
    room.pendingAction = null;
    if (room.currentDoubles === 0) endTurnInternal(room);
    emitRoom(room);
  });

  socket.on('build_house', ({ code, tileId }) => {
    const room = rooms[code];
    if (!room || room.pendingAction) return;
    const player = currentPlayer(room);
    if (!player || player.id !== socket.id) return;
    const tile = BOARD[tileId];
    const own = room.ownership[tileId];
    if (!tile || tile.type !== 'street' || !own || own.owner !== player.id) return;
    if (!ownedGroupComplete(room, player, tile.group)) return;
    if (own.houses >= 5) return;
    if (player.money < tile.houseCost) return;
    player.money -= tile.houseCost;
    own.houses++;
    pushLog(room, `🏗️ ${player.name} строит ${own.houses === 5 ? 'отель' : 'дом'} на «${tile.name}»`);
    emitRoom(room);
  });

  socket.on('pay_jail_fine', ({ code }) => {
    const room = rooms[code];
    if (!room) return;
    const player = currentPlayer(room);
    if (!player || player.id !== socket.id || !player.inJail) return;
    payPlayer(room, player, null, 50, 'выкуп из тюрьмы');
    player.inJail = false;
    player.jailTurns = 0;
    pushLog(room, `💵 ${player.name} платит $50 и выходит из тюрьмы`);
    emitRoom(room);
  });

  socket.on('end_turn', ({ code }) => {
    const room = rooms[code];
    if (!room) return;
    const player = currentPlayer(room);
    if (!player || player.id !== socket.id || room.pendingAction) return;
    endTurnInternal(room);
    emitRoom(room);
  });

  socket.on('chat_message', ({ code, text }) => {
    const room = rooms[code];
    if (!room || !text) return;
    const player = room.players.find(p => p.id === socket.id);
    if (!player) return;
    pushLog(room, `💬 ${player.name}: ${text.slice(0, 200)}`);
    emitRoom(room);
  });

  socket.on('disconnect', () => {
    for (const code of Object.keys(rooms)) {
      const room = rooms[code];
      const player = room.players.find(p => p.id === socket.id);
      if (player && !player.bankrupt) {
        pushLog(room, `❌ ${player.name} отключился`);
        handleBankruptcy(room, player, null, 'отключение');
        if (currentPlayer(room) && currentPlayer(room).id === socket.id) endTurnInternal(room);
        emitRoom(room);
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Сервер запущен на порту ${PORT}`));
