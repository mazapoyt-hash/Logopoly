// Игровая доска: 40 клеток, полностью оригинальные названия и баланс.
// group: цветовая группа улиц (для монопольного бонуса и застройки)

const GROUP_COLORS = {
  A: '#9C6B3E', // кофейный
  B: '#5FB8D9', // бирюзовый
  C: '#E0509A', // фуксия
  D: '#F2994A', // оранжевый
  E: '#E5514B', // алый
  F: '#F0CB4E', // янтарный
  G: '#33B36B', // изумрудный
  H: '#3E6FC4', // сапфировый
};

function street(id, name, group, price, baseRent) {
  return {
    id, type: 'street', name, group, price,
    color: GROUP_COLORS[group],
    baseRent,
    houseCost: Math.round(price * 0.5),
    // рента: [0 домов, 1, 2, 3, 4, отель]
    rentTable: [
      baseRent,
      baseRent * 5,
      baseRent * 15,
      baseRent * 30,
      baseRent * 45,
      baseRent * 60,
    ],
  };
}

function railroad(id, name) {
  return { id, type: 'railroad', name, price: 200, color: '#2b2b2b' };
}

function utility(id, name) {
  return { id, type: 'utility', name, price: 150, color: '#8a8a8a' };
}

const BOARD = [
  { id: 0, type: 'go', name: 'Старт' },
  street(1, 'ул. Ткачей', 'A', 60, 4),
  { id: 2, type: 'chest', name: 'Казна' },
  street(3, 'ул. Гончаров', 'A', 60, 8),
  { id: 4, type: 'tax', name: 'Подоходный налог', amount: 200 },
  railroad(5, 'Северный вокзал'),
  street(6, 'Бульвар Лазури', 'B', 100, 6),
  { id: 7, type: 'chance', name: 'Шанс' },
  street(8, 'Набережная Лазури', 'B', 100, 6),
  street(9, 'пр. Волны', 'B', 120, 8),
  { id: 10, type: 'jail', name: 'Тюрьма / Просто в гостях' },
  street(11, 'ул. Фуксии', 'C', 140, 10),
  utility(12, 'Электростанция'),
  street(13, 'пл. Фламинго', 'C', 140, 10),
  street(14, 'ул. Розовых Садов', 'C', 160, 12),
  railroad(15, 'Восточный вокзал'),
  street(16, 'пр. Заката', 'D', 180, 14),
  { id: 17, type: 'chest', name: 'Казна' },
  street(18, 'ул. Апельсиновая', 'D', 180, 14),
  street(19, 'пл. Мандарин', 'D', 200, 16),
  { id: 20, type: 'free_parking', name: 'Бесплатная парковка' },
  street(21, 'ул. Пламени', 'E', 220, 18),
  { id: 22, type: 'chance', name: 'Шанс' },
  street(23, 'пр. Рубиновый', 'E', 220, 18),
  street(24, 'пл. Гранат', 'E', 240, 20),
  railroad(25, 'Южный вокзал'),
  street(26, 'ул. Янтарная', 'F', 260, 22),
  street(27, 'пр. Солнечный', 'F', 260, 22),
  utility(28, 'Водоканал'),
  street(29, 'пл. Золотая', 'F', 280, 24),
  { id: 30, type: 'go_to_jail', name: 'Отправляйтесь в тюрьму' },
  street(31, 'ул. Изумрудная', 'G', 300, 26),
  street(32, 'пр. Малахитовый', 'G', 300, 26),
  { id: 33, type: 'chest', name: 'Казна' },
  street(34, 'пл. Нефритовая', 'G', 320, 28),
  railroad(35, 'Западный вокзал'),
  { id: 36, type: 'chance', name: 'Шанс' },
  street(37, 'наб. Сапфировая', 'H', 350, 35),
  { id: 38, type: 'luxury_tax', name: 'Налог на роскошь', amount: 100 },
  street(39, 'пл. Бриллиантовая', 'H', 400, 50),
];

const CHANCE_CARDS = [
  { text: 'Продвиньтесь до Старта. Получите $200', type: 'move_to', pos: 0, collectGo: true },
  { text: 'Банк начисляет вам дивиденды: получите $50', type: 'money', amount: 50 },
  { text: 'Штраф за превышение скорости: заплатите $15', type: 'money', amount: -15 },
  { text: 'Отправляйтесь в тюрьму, не проходя Старт', type: 'goto_jail' },
  { text: 'Вы выиграли конкурс: получите $25', type: 'money', amount: 25 },
  { text: 'Пройдите вперёд на 3 клетки', type: 'move_relative', steps: 3 },
  { text: 'Досталось наследство: получите $100', type: 'money', amount: 100 },
  { text: 'Ремонт дорог: заплатите $40 за каждый дом и $115 за отель', type: 'repair', perHouse: 40, perHotel: 115 },
  { text: 'Все игроки платят вам по $10 за консультацию', type: 'collect_from_all', amount: 10 },
];

const CHEST_CARDS = [
  { text: 'Ошибка банка в вашу пользу: получите $200', type: 'money', amount: 200 },
  { text: 'Оплата врача: заплатите $50', type: 'money', amount: -50 },
  { text: 'Продажа облигаций: получите $45', type: 'money', amount: 45 },
  { text: 'Отправляйтесь в тюрьму, не проходя Старт', type: 'goto_jail' },
  { text: 'Налоговый возврат: получите $20', type: 'money', amount: 20 },
  { text: 'Вы получили наследство: получите $100', type: 'money', amount: 100 },
  { text: 'Оплата обучения: заплатите $50', type: 'money', amount: -50 },
  { text: 'Праздничный фонд: получите по $10 от каждого игрока', type: 'collect_from_all', amount: 10 },
  { text: 'Штраф за парковку: заплатите $15', type: 'money', amount: -15 },
];

module.exports = { BOARD, CHANCE_CARDS, CHEST_CARDS, GROUP_COLORS };
